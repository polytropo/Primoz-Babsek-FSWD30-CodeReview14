<?php

/* event/index.html.twig */
class __TwigTemplate_3fd78ff0e99a3472a327b9e8e3cd4199402d65b3b3867ebdf60dd03486f19dfa extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "event/index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "event/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "event/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "
        

\t<h2 class=\"page-header\">Events</h2>
\t<div class=\"row\">


   
";
        // line 13
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["events"] ?? $this->getContext($context, "events")));
        foreach ($context['_seq'] as $context["_key"] => $context["event"]) {
            // line 14
            echo "        
\t\t<div class=\"col-xs-12 col-sm-6 col-md-4 col-lg-4\" style=\"margin-bottom:1.5em;\">
        
\t\t\t<img src=\"";
            // line 17
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "imageUrl", array()), "html", null, true);
            echo "\" style=\"width:100%;\">
            <p scope=\"row\"><strong>";
            // line 18
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "type", array()), "html", null, true);
            echo "</strong></p>

            <p class=\"h3\">";
            // line 20
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "eventName", array()), "html", null, true);
            echo "</p>

            <p class=\"h4\">We have space for: ";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "capacity", array()), "html", null, true);
            echo " people</p>

            <div> <a href=\"/event/details/";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "id", array()), "html", null, true);
            echo "\" class=\"btn btn-success\">View</a>

            <a href=\"/event/edit/";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "id", array()), "html", null, true);
            echo "\" class=\"btn btn-warning\">Edit</a>

            <a href=\"/event/delete/";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "id", array()), "html", null, true);
            echo "\" class=\"btn btn-danger\">Delete</a>        
            <hr>    
            </div>
        </div>

 

";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['event'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 36
        echo "
</div>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "event/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  111 => 36,  97 => 28,  92 => 26,  87 => 24,  82 => 22,  77 => 20,  72 => 18,  68 => 17,  63 => 14,  59 => 13,  49 => 5,  40 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}


{% block body %}

        

\t<h2 class=\"page-header\">Events</h2>
\t<div class=\"row\">


   
{% for event in events %}
        
\t\t<div class=\"col-xs-12 col-sm-6 col-md-4 col-lg-4\" style=\"margin-bottom:1.5em;\">
        
\t\t\t<img src=\"{{event.imageUrl}}\" style=\"width:100%;\">
            <p scope=\"row\"><strong>{{event.type}}</strong></p>

            <p class=\"h3\">{{event.eventName}}</p>

            <p class=\"h4\">We have space for: {{event.capacity}} people</p>

            <div> <a href=\"/event/details/{{event.id}}\" class=\"btn btn-success\">View</a>

            <a href=\"/event/edit/{{event.id}}\" class=\"btn btn-warning\">Edit</a>

            <a href=\"/event/delete/{{event.id}}\" class=\"btn btn-danger\">Delete</a>        
            <hr>    
            </div>
        </div>

 

{% endfor %}

</div>

{% endblock %}", "event/index.html.twig", "C:\\xampp\\htdocs\\Symfony\\eventlist\\app\\Resources\\views\\event\\index.html.twig");
    }
}
