<?php

/* event/details.html.twig */
class __TwigTemplate_937457e322f7960ae405bf3dd1f558e5925965615a2ae8497a298df479d7dfa2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "event/details.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "event/details.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "event/details.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "
        <a class=\"btn btn-primary\" href=\"/\">Back to Events</a>

        <hr>
        <div class=\"row\">
        <h2 class=\"page-header\">";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "eventName", array()), "html", null, true);
        echo "</h2>

        <ul class=\"list-group\">
                <img src=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "imageUrl", array()), "html", null, true);
        echo "\" style=\"max-width:40%;\">
                <li class=\"list-group-item\">Event ID: ";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "eventName", array()), "html", null, true);
        echo "</li>
                <li class=\"list-group-item\">Capacity: ";
        // line 15
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "capacity", array()), "html", null, true);
        echo "</li>
                <li class=\"list-group-item\">Event Type: ";
        // line 16
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "type", array()), "html", null, true);
        echo "</li>
                <li class=\"list-group-item\">Phone: ";
        // line 17
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "phone", array()), "html", null, true);
        echo "</li>
                <li class=\"list-group-item\">Email: ";
        // line 18
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "email", array()), "html", null, true);
        echo "</li>
                <li class=\"list-group-item\">Address: ";
        // line 19
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "address", array()), "html", null, true);
        echo "</li>
                <li class=\"list-group-item\">WebPage: ";
        // line 20
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "url", array()), "html", null, true);
        echo " - <a href=\"";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "url", array()), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "url", array()), "html", null, true);
        echo "</a></li>
                <li class=\"list-group-item\">Event ends on: ";
        // line 21
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "eventEnd", array()), "F j, Y, g:i a"), "html", null, true);
        echo "</li>
                <li class=\"list-group-item\">Event starts on: ";
        // line 22
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "eventStart", array()), "F j, Y, g:i a"), "html", null, true);
        echo "</li>
                <li class=\"list-group-item\">Description: ";
        // line 23
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "description", array()), "html", null, true);
        echo "</li>
        </ul>
        </div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "event/details.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  106 => 23,  102 => 22,  98 => 21,  90 => 20,  86 => 19,  82 => 18,  78 => 17,  74 => 16,  70 => 15,  66 => 14,  62 => 13,  56 => 10,  49 => 5,  40 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}


{% block body %}

        <a class=\"btn btn-primary\" href=\"/\">Back to Events</a>

        <hr>
        <div class=\"row\">
        <h2 class=\"page-header\">{{event.eventName}}</h2>

        <ul class=\"list-group\">
                <img src=\"{{event.imageUrl}}\" style=\"max-width:40%;\">
                <li class=\"list-group-item\">Event ID: {{event.eventName}}</li>
                <li class=\"list-group-item\">Capacity: {{event.capacity}}</li>
                <li class=\"list-group-item\">Event Type: {{event.type}}</li>
                <li class=\"list-group-item\">Phone: {{event.phone}}</li>
                <li class=\"list-group-item\">Email: {{event.email}}</li>
                <li class=\"list-group-item\">Address: {{event.address}}</li>
                <li class=\"list-group-item\">WebPage: {{event.url}} - <a href=\"{{event.url}}\">{{event.url}}</a></li>
                <li class=\"list-group-item\">Event ends on: {{event.eventEnd|date('F j, Y, g:i a')}}</li>
                <li class=\"list-group-item\">Event starts on: {{event.eventStart|date('F j, Y, g:i a')}}</li>
                <li class=\"list-group-item\">Description: {{event.description}}</li>
        </ul>
        </div>
{% endblock %}


", "event/details.html.twig", "C:\\xampp\\htdocs\\Symfony\\eventlist\\app\\Resources\\views\\event\\details.html.twig");
    }
}
