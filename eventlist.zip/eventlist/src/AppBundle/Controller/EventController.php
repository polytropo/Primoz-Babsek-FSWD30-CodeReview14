<?php


namespace AppBundle\Controller;

use AppBundle\Entity\Events;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\EventDispatcher\Event;
use Doctrine\ORM\EntityManagerInterface;



class EventController extends Controller

{

    /**

     * @Route("/", name="event_list")

     */

    public function listAction(){

        $events = $this->getDoctrine()->getRepository('AppBundle:Events')->findAll();

        // replace this example code with whatever you need

        return $this->render('event/index.html.twig', array('events'=>$events));

    }



     /**

     * @Route("/event/create", name="event_create")

     */

    public function createAction(Request $request){


        $event = new Events;


        $form = $this->createFormBuilder($event)

        ->add('event_name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('description', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('image_url', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('capacity', NumberType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('email', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('phone', NumberType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('address', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('url', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('type', ChoiceType::class, array('choices'=>array('Sports'=>'Sports', 'Theater'=>'Theater', 'Music'=>'Music'),'attr' => array('class'=> 'form-control', 'style'=>'margin-botton:15px')))
    	->add('event_start', DateTimeType::class, array('attr' => array('style'=>'margin-bottom:15px')))
    	->add('event_end', DateTimeType::class, array('attr' => array('style'=>'margin-bottom:15px')))

    	->add('save', SubmitType::class, array('label'=> 'Create event', 'attr' => array('class'=> 'btn-primary', 'style'=>'margin-bottom:15px')))


        ->getForm();


        $form->handleRequest($request);


        if($form->isSubmitted() && $form->isValid()){

            //fetching data

            $eventName = $form['event_name']->getData();
            $description = $form['description']->getData();
            $image_url = $form['image_url']->getData();
            $capacity = $form['capacity']->getData();
            $email = $form['email']->getData();
            $phone = $form['phone']->getData();
            $address = $form['address']->getData();
            $url = $form['url']->getData();
            $type = $form['type']->getData();
            $event_start = $form['event_start']->getData();
            $event_end = $form['event_end']->getData();

      

            $event->setEventName($eventName);
            $event->setEventStart($event_start);
            $event->setEventEnd($event_end);
            $event->setDescription($description);
            $event->setImageUrl($image_url);
            $event->setCapacity($capacity);
            $event->setEmail($email);
            $event->setPhone($phone);
            $event->setAddress($address);
            $event->setUrl($url);
            $event->setType($type);


            $em = $this->getDoctrine()->getManager();


            $em->persist($event);


            $em->flush();


            $this->addFlash(

                    'notice',

                    'event Added'

                    );


            return $this->redirectToRoute('event_list');


        }

        // replace this example code with whatever you need

        return $this->render('event/create.html.twig', array('form' => $form->createView()));

    }



    /**
        * @Route("/event/edit/{id}", name="event_edit")
        */

        public function editEvent( $id, Request $request){

    	    $event = $this->getDoctrine()->getRepository('AppBundle:Events')->find($id);

    	    
    	    $event->setEventName($event->getEventName());
    		$event->setEventStart($event->getEventStart());
    		$event->setEventEnd($event->getEventEnd());
    		$event->setDescription($event->getDescription());
    		$event->setImageUrl($event->getImageUrl());
    		$event->setCapacity($event->getCapacity());
    		$event->setEmail($event->getEmail());
    		$event->setPhone($event->getPhone());
    		$event->setAddress($event->getAddress());
    		$event->setUrl($event->getUrl());
    		$event->setType($event->getType());



    	    $form = $this->createFormBuilder($event)

	        ->add('event_name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
	        ->add('description', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
	        ->add('image_url', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
	        ->add('capacity', NumberType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
	        ->add('email', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
	        ->add('phone', NumberType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
	        ->add('address', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
	        ->add('url', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
	        ->add('type', ChoiceType::class, array('choices'=>array('Sports'=>'Sports', 'Theater'=>'Theater', 'Music'=>'Music'),'attr' => array('class'=> 'form-control', 'style'=>'margin-botton:15px')))
	    	->add('event_start', DateTimeType::class, array('attr' => array('style'=>'margin-bottom:15px')))
	    	->add('event_end', DateTimeType::class, array('attr' => array('style'=>'margin-bottom:15px')))

    	    //submit form
    	    ->add('save', SubmitType::class, array('label'=> 'Edit Event', 'attr' => array('class'=> 'btn-primary', 'style'=>'margin-botton:15px')))

    	    ->getForm();


    	    $form->handleRequest($request);

    	    if($form->isSubmitted() && $form->isValid()){

    	        //fetching data
    	    	$eventName   	= $form['event_name']->getData();
	            $description 	= $form['description']->getData();
	            $image_url 		= $form['image_url']->getData();
	            $capacity 		= $form['capacity']->getData();
	            $email 			= $form['email']->getData();
	            $phone 			= $form['phone']->getData();
	            $address 		= $form['address']->getData();
	            $url 			= $form['url']->getData();
	            $type 			= $form['type']->getData();
	            $event_start 	= $form['event_start']->getData();
	            $event_end 		= $form['event_end']->getData();

    	    	$em = $this->getDoctrine()->getManager();

    	    	$event = $em->getRepository('AppBundle:Events')->find($id);

    	    	$event->setEventName($eventName);
            	$event->setEventStart($event_start);
            	$event->setEventEnd($event_end);
            	$event->setDescription($description);
            	$event->setImageUrl($image_url);
            	$event->setCapacity($capacity);
            	$event->setEmail($email);
            	$event->setPhone($phone);
            	$event->setAddress($address);
            	$event->setUrl($url);
            	$event->setType($type);
    	    	
    	        $em->flush();

    	        $this->addFlash(

    	            'notice',
    	            'Event Updated'

    	            );

    	        return $this->redirectToRoute('event_list');

    	    }

    	    return $this->render('event/edit.html.twig', array('event' => $event, 'form' => $form->createView()));
    	}



     /**

     * @Route("/event/details/{id}", name="event_details")

     */

    
    public function detailsAction($id){

		$event = $this->getDoctrine()->getRepository('AppBundle:Events')->find($id);
		return $this->render('event/details.html.twig', array('event' => $event));

    }


    /**

     * @Route("/event/delete/{id}", name="event_delete")

     */

    public function deleteAction($id){

            $em = $this->getDoctrine()->getManager();

            $event = $em->getRepository('AppBundle:Events')->find($id);


            $em->remove($event);


            $em->flush();


            $this->addFlash(

                    'notice',

                    'Event Removed'

                    );


             return $this->redirectToRoute('event_list');


    }

}

