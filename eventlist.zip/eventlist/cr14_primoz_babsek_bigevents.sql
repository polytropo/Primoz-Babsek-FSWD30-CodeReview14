-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 10, 2018 at 12:54 PM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cr14_primoz_babsek_bigevents`
--

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `event_name` varchar(255) NOT NULL,
  `event_start` datetime NOT NULL,
  `event_end` datetime NOT NULL,
  `description` text NOT NULL,
  `image_url` varchar(255) NOT NULL,
  `capacity` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` int(11) NOT NULL,
  `address` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `event_name`, `event_start`, `event_end`, `description`, `image_url`, `capacity`, `email`, `phone`, `address`, `url`, `type`) VALUES
(1, 'Eisstockschießen am Badeschiff', '2018-03-09 16:00:00', '2018-03-09 22:00:00', 'Eisstockschießen am Badeschiff(2 Bahnen, Anmeldung im Susi-Haus am Festland)', 'https://fcc.at/event/img500/87568.jpeg', 60, 'eisstockschien@gmail.com', 112233, 'Badeschiff, 1020 Wien, Austria', 'Eisstockschieen.com', 'Sports'),
(2, 'Vienna Baroque Orchestra', '2018-04-04 20:15:00', '2018-04-04 22:00:00', 'Classical Concerts in Vienna, no dress code for this one', 'https://www.viennaconcerts.com/images/barockorchester.jpg', 199, 'concert1@gmail.com', 77889944, 'Renngasse 4, 1100 Wien, Austria', 'conecrt1.com', 'Theater'),
(5, 'Ulrich Troyer (DJ Set)', '2018-04-06 00:00:00', '2018-04-06 15:00:00', 'Best djs on tour now in vienna live, dont miss the chance', 'https://images.sk-static.com/images/media/profile_images/artists/8476418/huge_avatar', 1400, 'ulrich@gmail.com', 66558899, 'Deli Am Naschmarkt, Vienna, Austria', 'https://www.songkick.com/artists/8476418-ulrich-troyer-dj-set', 'Music'),
(6, 'Rapid Wien', '2018-03-04 20:00:00', '2018-03-04 23:00:00', 'Launch of the spring season', 'http://www.viennadirect.com/images/activity/stadium_r.jpg', 25000, 'rapid@gmail.com', 123456, 'rapid vienna 12, vienna 1100, austria', 'rapid.com', 'Sports');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
